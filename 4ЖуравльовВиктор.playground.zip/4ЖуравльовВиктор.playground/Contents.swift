import UIKit

class Car {
    enum Engine {
        case diesel, petrol, electric
    }
    
    enum Motor {
        case on, off
    }
    
    var numberOfWheels: Int
    var door: Int
    var motorType: Engine
    var statusMotor: Motor = .off
    
    init(numberOfWheels: Int, door: Int, motorType: Engine) {
        self.numberOfWheels = numberOfWheels
        self.door = door
        self.motorType = motorType
    }
    
    func status() -> String {
        "Car have \(numberOfWheels) wheels,  \(door) doors, type of engine is \(motorType)"
    }
}

class TrunkCar: Car {
    
    enum Trailer {
        case present(ton: Int)
        case notPresent(ton: Int)
    }
    
    var statusTrailer: Trailer
    
    init(statusTrailer: Trailer, numberOfWheels: Int, door: Int, motorType: Engine) {
        self.statusTrailer = statusTrailer
        super.init(numberOfWheels: numberOfWheels, door: door, motorType: motorType)
    }
    
    func startEngine() {
        statusMotor = .on
    }
    
    override func status() -> String {
        return super.status() + ", trunk have \(statusTrailer)"
    }
}

class SportCar: Car {
    
    enum Roof {
        case open, closed, notMove
    }
    
    var roof: Roof
    var speed: Int
    
    init(roof: Roof,speed: Int, numberOfWheels: Int, door: Int, motorType: Engine) {
        self.speed = speed
        self.roof = roof
        super.init(numberOfWheels: numberOfWheels, door: door, motorType: motorType)
    }
    
    func engineWork(isStart: Bool) {
        return isStart ? (statusMotor = .on) : (statusMotor = .off)
    }
    
    func roofMove(isStartOpen: Bool) {
        if roof != .notMove {
            return isStartOpen ? (roof = .open) : (roof = .closed)
        } else {
            print("Roof not moved")
        }
    }
}
var volvo = TrunkCar(statusTrailer: .present(ton: 20), numberOfWheels: 6, door: 2, motorType: .diesel)
print(volvo.status())
volvo.startEngine()

var ladaCalina = SportCar(roof: .notMove, speed: 60, numberOfWheels: 4, door: 4, motorType: .electric)
ladaCalina.engineWork(isStart: true)
ladaCalina.roofMove(isStartOpen: true)
print(ladaCalina.status())

