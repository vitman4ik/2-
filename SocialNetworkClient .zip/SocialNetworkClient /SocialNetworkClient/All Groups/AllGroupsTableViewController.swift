//
//  AllGroupsTableViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

class AllGroupsTableViewController: UITableViewController, UISearchBarDelegate {
    
    static let kHeaderHeight: CGFloat = 50.0
    
    var iniatialGroupArray = [GroupModel]()
    
    var groups = GroupModel.generateGroupsData()
    var isFiltered = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        iniatialGroupArray = groups
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GroupsCell", for: indexPath) as! GroupsTableViewCell
        
        cell.groupsName.text = groups[indexPath.row].group
        cell.groupsPhoto.image = groups[indexPath.row].photo
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: AllGroupsTableViewController.kHeaderHeight))
        
        let searchBar = UISearchBar(frame: headerView.frame)
        
        headerView.addSubview(searchBar)
        searchBar.delegate = self
        
        return headerView
    }
    
    func search(by text: String) {
        isFiltered = !text.isEmpty
        
        if isFiltered {
            groups = iniatialGroupArray.filter({ $0.group.lowercased().contains(text.lowercased())})
        } else {
            groups = iniatialGroupArray
        }
        
        tableView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let currentText = searchBar.text ?? ""
        
        guard let stringRange = Range(range, in: currentText) else { return false }
        let updatedText = currentText.replacingCharacters(in: stringRange, with: text)
        
        search(by: updatedText)
        
        return  true
    }
}
