//
//  UIAlertController+Show.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 05.02.2021.
//

import UIKit

extension UIViewController {
    
    func showAlert(with title: String, and message: String) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
}
