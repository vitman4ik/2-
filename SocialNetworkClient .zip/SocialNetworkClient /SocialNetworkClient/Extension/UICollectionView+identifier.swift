//
//  UICollectionView+identifier.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 01.03.2021.
//

import UIKit

extension UICollectionViewCell {
    static var id: String {
        String(describing: self)
    }
}
