//
//  UITableViewCell+id.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 23.02.2021.
//

import UIKit

extension UITableViewCell {
    static var id: String {
        String(describing: self)
    }
}
