//
//  FriendsTableViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

class FriendsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var friends: UILabel!
    
    @IBOutlet weak var photoFriends: UIImageView!
    
   /* let animation = Animations()
    
    lazy var tapGestureRecognizer: UITapGestureRecognizer = {
        let recognize = UITapGestureRecognizer(target: self, action: #selector(onTap))
        recognize.numberOfTouchesRequired = 1
        recognize.numberOfTouchesRequired = 1
        
        
        return recognize
    }()
    
    @objc func onTap() {
        animation.springAnimation(self)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        addGestureRecognizer(tapGestureRecognizer)
    }
   */
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
