//
//  FriendsTableViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

class FriendsTableViewController: UITableViewController {
    
    static let kHeaderViewHeight: CGFloat = 50.0
    
    var friends = FriendModel.generateFriendsData()
    var sectionData = [[FriendModel]]()
    var sectionsTitle = Set<String>()
    var isFilteringMode = false
    var filteredSectionData = [[FriendModel]]()
    var filteredSectionsTitle = Set<String>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let result = generateNewData(from: friends)
        sectionData = result.sectionModel
        sectionsTitle = result.headerModel
        tableView.reloadData()
        
        createHeaderView()
    }
    
    private func createHeaderView() {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: FriendsTableViewController.kHeaderViewHeight))
        let searchBar = UISearchBar(frame: headerView.frame)
        searchBar.center = headerView.center
        searchBar.placeholder = "Search"
        searchBar.delegate = self
        headerView.addSubview(searchBar)
        tableView.tableHeaderView = headerView
    }
    
    func generateNewData(from model: [FriendModel]) -> (sectionModel: [[FriendModel]], headerModel: Set<String>) {
        var headerArray = Set<String>()
        var sectionArrayModel = [[FriendModel]]()
        
        for item in model {
            if let firstLetter = item.name.first,
               !headerArray.contains(String(firstLetter)) {
                headerArray.insert(String(firstLetter))
            }
        }
        
        var newArray = [FriendModel]()
        for title in headerArray {
            for friend in model {
                if let firstLetter = friend.name.first,
                   title == String(firstLetter) {
                    newArray.append(friend)
                }
            }
            sectionArrayModel.append(newArray)
            newArray.removeAll()
            tableView.reloadData()
        }
        
        return (sectionArrayModel, headerArray)
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return isFilteringMode ? filteredSectionData.count : sectionData.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return isFilteringMode ? filteredSectionData[section].count : sectionData[section].count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = isFilteringMode ? filteredSectionData[indexPath.section][indexPath.row] : sectionData[indexPath.section][indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "friendsCell", for: indexPath) as! FriendsTableViewCell
        
        cell.friends.text = data.name
        cell.photoFriends.image = data.coverPhoto
        
        
        
        // Configure the cell...
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let degree: Double = 90
        let rotationAngle = CGFloat(degree * M_PI / 180)
        let rotationTransform = CATransform3DMakeRotation(rotationAngle, 0, 1, 0)
        cell.layer.transform = rotationTransform
        
        UIView.animate(withDuration: 1, delay: 0.2, options: .curveEaseInOut, animations: {cell.layer.transform = CATransform3DIdentity})
        
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 44.0))
        
        headerView.backgroundColor = .systemBackground
        let label = UILabel(frame: CGRect(x: 22, y: 16, width: tableView.frame.width - 22, height: 20))
        headerView.addSubview(label)
        
        label.text = isFilteringMode ? Array(filteredSectionsTitle)[section] : Array(sectionsTitle)[section]
        
        return headerView
    }
    
//    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return isFilteringMode ? Array(filteredSectionsTitle)[section] : Array(sectionsTitle)[section]
//    }
//
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let friend = friends[indexPath.row]
        performSegue(withIdentifier: "showFriendData", sender: friend)
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return isFilteringMode ? Array(filteredSectionsTitle) : Array(sectionsTitle)
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let friendsPhotoCollectionViewController = segue.destination as? FriendsPhotoCollectionViewController,
           
           let friend = sender as? FriendModel {
            
            friendsPhotoCollectionViewController.friend = friend
        }
    }
    
    fileprivate func search(by text: String) {
        isFilteringMode = !text.isEmpty
        
        if !isFilteringMode {
            filteredSectionData.removeAll()
            
        } else {
            
            var filteredFriendModel = [FriendModel]()
            
            for friendModel in sectionData {
                for model in friendModel {
                    if model.name.lowercased().contains(text.lowercased()) {
                        filteredFriendModel.append(model)
                    }
                }
            }
            
            let result = generateNewData(from: filteredFriendModel)
            
            filteredSectionData = result.sectionModel
            filteredSectionsTitle = result.headerModel
        }
        
        tableView.reloadData()
    }
}

// MARK: - UISearchBarDelegate
    
extension FriendsTableViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let currentText = searchBar.text ?? ""

        search(by: currentText)
    }
}
