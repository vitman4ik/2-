//
//  RegistrationViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 03.02.2021.
//

import UIKit

class RegistrationViewController: UIViewController {
    
    @IBOutlet weak var loginTextFild: UITextField!
    
    @IBOutlet weak var passwordTextFild: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func registration(_ sender: UIButton) {
        
        guard let login = loginTextFild.text,
              !login.isEmpty else {
            showAlert(with: "Error", and: "Wrong login")
            return
        }
        
        guard let password = passwordTextFild.text,
              !password.isEmpty else {
            showAlert(with: "Error", and: "Wrong password")
            return}
        
        AllUsers.user.usersArray.append(Users(login: login, password: password))
        
        showAlert(with: "Congratulations", and: "You are the new User")
        
    }
    @IBAction func goToLogin(_ sender: UIButton) {
        performSegue(withIdentifier: "goToLogin", sender: nil)
    }
}
