//
//  Session.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 15.03.2021.
//

import Foundation

class Session {
    static  let shered = Session()
    
    private init() {}
    
    var token: String?
    var userld: Int?
}
