//
//  ViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 02.02.2021.
//

import UIKit

class Login: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var firstElementLoad: UIImageView!
    @IBOutlet weak var secondElementLoad: UIImageView!
    @IBOutlet weak var thirdElementLoad: UIImageView!
    
    let anim = Animations()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let hideKeybordResture = UITapGestureRecognizer(target: self, action: #selector(hideKeybord))
        scrollView?.addGestureRecognizer(hideKeybordResture)
        
    }
    
    func animationLoad() {
        anim.loadingElement(firstElementLoad, duration: 0.75, delay: 0.75)
        anim.loadingElement(secondElementLoad, duration: 0.75, delay: 1)
        anim.loadingElement(thirdElementLoad, duration: 0.75, delay: 1.25)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        animationLoad()
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keybordWsaShown), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func hideKeybord(){
        self.scrollView?.endEditing(true)
    }
    
    @objc func keybordWsaShown(notification: Notification){
        
        let info = notification.userInfo! as NSDictionary
        
        let kbSize = (info.value(forKey: UIResponder.keyboardFrameEndUserInfoKey) as! NSValue).cgRectValue.size
        
        let contentInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        
        self.scrollView?.contentInset = contentInsets
        
        scrollView?.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillBeHidden(notification: Notification) {
        
        let contentInsets = UIEdgeInsets.zero
        scrollView?.contentInset = contentInsets
    }
    
    
    @IBAction func unwindToMainScreen(_ segue: UIStoryboardSegue) {
        guard segue.identifier == "goToLogin" else {return}
        
    }
    
    @IBAction func singInButton(_ sender: UIButton) {
        
        guard let login = loginTextField.text,
              !login.isEmpty else {
            showAlert(with: "Error", and: "Wrong login")
            return
        }
        guard let password = passwordTextField.text,
              !password.isEmpty else {
            showAlert(with: "Error", and: "Wrong password")
            return}
        
        if AllUsers.user.usersArray.isEmpty {
            showAlert(with: "Error", and: "No Users, go to registration")
        }
        
        for user in AllUsers.user.usersArray {
            if (login == user.login) && (password == user.password)
            {
                pushToHomeScreen()
            } else {
                showAlert(with: "Error", and: "No User")
            }
        }
    }
    
    @IBAction func registrationButton(_ sender: UIButton) {
        performSegue(withIdentifier: "loginToRegistration", sender: nil)
        
    }
    
    private func pushToHomeScreen() {
        if let tabBarController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "111") as? UITabBarController {
            tabBarController.modalPresentationStyle = .fullScreen
            tabBarController.modalTransitionStyle = .crossDissolve
            present(tabBarController, animated: true, completion: nil)
        }
    }
}


