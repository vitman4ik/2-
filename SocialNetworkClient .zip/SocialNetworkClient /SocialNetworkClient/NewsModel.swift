//
//  NewsModel.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 22.02.2021.
//

import UIKit

/*struct NewsModel {
    var user: String
    var date: String
    var news: String
    var newsPhoto: UIImage?
    
    static func generateNews() -> [NewsModel] {
    return [ NewsModel(user: "Billi", date: "16.06.2020", news: "Italy's ambassador to the Democratic Republic of Congo has been killed in an attack in the east of the country, its foreign ministry has said.", newsPhoto: UIImage(named: "kill")), NewsModel(user: "Milli", date: "22.02.2020", news: "The family of an 11-year-old boy who died in recent cold weather in Texas have filed a $100m (£71m) lawsuit against power companies for negligence.", newsPhoto: UIImage(named: "boy") )]
        
    
}

}


*/
