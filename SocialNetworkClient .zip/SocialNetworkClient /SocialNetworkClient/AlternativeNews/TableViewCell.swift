//
//  TableViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 23.02.2021.
//

import UIKit

protocol TableViewCellDelegate: AnyObject {
    func didlikeButton(_ isFavurite: Bool)
}

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var peopleAvatar: UIImageView!
    @IBOutlet weak var nikPeople: UILabel!
    @IBOutlet weak var datePost: UILabel!
    @IBOutlet weak var descriptionNews: UILabel!
    @IBOutlet weak var photoForNewsCollectionView: UICollectionView!
    @IBOutlet weak var numberOfLike: UILabel!
    
    weak var delegete: TableViewCellDelegate?
    
    var newsPhoto = [UIImage]()
    
    func setupNewsPhoto(_ newsPhoto: [UIImage]) {
        self.newsPhoto = newsPhoto
        photoForNewsCollectionView.reloadData()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()

        photoForNewsCollectionView.dataSource = self
        photoForNewsCollectionView.delegate = self
        photoForNewsCollectionView.register(UINib(nibName: NewsPhotoCollectionViewCell.id, bundle: nil),
                                            forCellWithReuseIdentifier: NewsPhotoCollectionViewCell.id)
    }

    @IBAction func shereNews(_ sender: UIButton) {
    }
    
    @IBAction func likeButton(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        let count = Int(numberOfLike.text ?? "0") ?? 0
        let sum = sender.isSelected ? count + 1 : count - 1
        numberOfLike.text = "\(sum)"
        delegete?.didlikeButton(sender.isSelected)
        Animations.animationTapToLike(sender)
    }
}

// MARK: - UICollectionViewDataSource

extension TableViewCell: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return newsPhoto.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: NewsPhotoCollectionViewCell.id, for: indexPath) as? NewsPhotoCollectionViewCell else {
            fatalError()
        }
        
        cell.photoImageView.image = newsPhoto[indexPath.row]
        
        return cell
    }

}

// MARK: - UICollectionViewDelegateFlowLayout

extension TableViewCell: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
}
