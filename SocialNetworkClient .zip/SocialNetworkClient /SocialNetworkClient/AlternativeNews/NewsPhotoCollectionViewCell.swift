//
//  NewsPhotoCollectionViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 23.02.2021.
//

import UIKit

class NewsPhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
