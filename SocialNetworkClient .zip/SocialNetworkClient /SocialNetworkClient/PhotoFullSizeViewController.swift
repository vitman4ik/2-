//
//  PhotoFullSizeViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 07.03.2021.
//

import UIKit

class PhotoFullSizeViewController: UIViewController {
    
    @IBOutlet weak var nextPhoto: UIImageView!
    @IBOutlet weak var likeControl: UIButton!
    @IBOutlet weak var currentPhoto: UIImageView!
    
    var profilePhoto = [UIImage]()
    var currentPhotoNumber = 0
    let interactiveAnimator = UIViewPropertyAnimator(duration: 0.8, curve: .easeInOut)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        swipesObserver()
        tapObserver()
        //panObserver()
        
        currentPhoto.image = profilePhoto[currentPhotoNumber]
    }
    
    func swipesObserver() {
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes))
        leftSwipe.direction = .left
        self.view.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes))
        rightSwipe.direction = .right
        self.view.addGestureRecognizer(rightSwipe)
    }
    
    @objc func handleSwipes(gesture: UISwipeGestureRecognizer) {
        switch gesture.direction {
        case .left:
            guard profilePhoto.indices.contains(currentPhotoNumber + 1) else { return }
            setupNexPhoto(nextOrPrevious: 1, offset: view.bounds.width)
            animatePotosV2() //
        currentPhotoNumber += 1
            
        case .right:
            guard profilePhoto.indices.contains(currentPhotoNumber - 1) else { return }
            setupNexPhoto(nextOrPrevious: -1, offset: -view.bounds.width)
            animatePotosV2() //
            currentPhotoNumber -= 1
            
        default:
            break
        }
    }
    
    func tapObserver() {
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleTapAction))
        doubleTap.numberOfTapsRequired = 2 //
        self.view.addGestureRecognizer(doubleTap)
    }
    
    @objc func handleTapAction(gesture: UITapGestureRecognizer) {
      //  likeControl.button.sendActions( for: .touchUpInside)
    }
    
    func panObserver() {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(viewPanned))
        self.view.addGestureRecognizer(pan)
    }
    
    @objc func viewPanned(gesture: UIPanGestureRecognizer) {
        let velocity = gesture.velocity(in: self.view)
        
        switch gesture.state {
        case .began:
            if velocity.x < 0 {
                guard profilePhoto.indices.contains(currentPhotoNumber + 1) else { return }
                setupNexPhoto( nextOrPrevious: 1, offset: view.bounds.width)
            } else {
                guard profilePhoto.indices.contains(currentPhotoNumber - 1) else { return }
                setupNexPhoto( nextOrPrevious: -1, offset: -view.bounds.width)
            }
            
            interactiveAnimator.addAnimations {
                self.animatePotosV2()
            }
            interactiveAnimator.pauseAnimation()
            
        case .changed:
            let translation = gesture.translation(in: self.view)
            interactiveAnimator.fractionComplete = abs(translation.x / 300)
            
        case .ended:
            interactiveAnimator.continueAnimation(withTimingParameters: nil, durationFactor: 0)
            if velocity.x < 0 {
                guard profilePhoto.indices.contains(currentPhotoNumber + 1) else { return }
                currentPhotoNumber += 1
            } else {
                guard profilePhoto.indices.contains(currentPhotoNumber - 1) else { return }
            }
            
            
        default:
            break
           
        }
    }
    
    func setupNexPhoto(nextOrPrevious: Int, offset: CGFloat) {
        
        guard profilePhoto.indices.contains(currentPhotoNumber + nextOrPrevious) else { return }
        
        if currentPhotoNumber % 2 == 0 {
            nextPhoto.transform = CGAffineTransform(scaleX: offset, y: 0)
            nextPhoto.image = profilePhoto[currentPhotoNumber + nextOrPrevious]
            nextPhoto.alpha = 1
        } else {
            currentPhoto.transform = CGAffineTransform(scaleX: offset, y: 0)
            currentPhoto.image = profilePhoto[currentPhotoNumber + nextOrPrevious]
            currentPhoto.alpha = 1
    }
    
    }
    
    func animatePhotos() {
        UIView.animateKeyframes(withDuration: 0.8,
                                delay: 0,
                                options: [],
                                animations: {
                                    UIView.addKeyframe(withRelativeStartTime: 0,
                                                       relativeDuration: 0.5,
                                                       animations: {
                                                        if self.currentPhotoNumber % 2 == 0 {
                                                            self.currentPhoto.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
                                                            self.currentPhoto.alpha = 0
                                                        }else {
                                                            self.nextPhoto.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
                                                            self.currentPhoto.alpha = 0
                                                        }
                                                       })
                                    UIView.addKeyframe(withRelativeStartTime: 0.25,
                                                       relativeDuration: 0.75,
                                                       animations: {
                                                        if self.currentPhotoNumber % 2 == 0 {
                                                            self.nextPhoto.transform = .identity
                                                        } else {
                                                            self.currentPhoto.transform = .identity
                                                        }
                                                       })
                                            })
    }
    
    func animatePotosV2() {
        UIView.animate(withDuration: 0.1,
                       delay: 0,
                       options: [],
                       animations: {
                        if self.currentPhotoNumber % 2 == 0{
                            self.currentPhoto .transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
                            self.currentPhoto.alpha = 0
                        } else {
                            self.nextPhoto.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
                            self.nextPhoto.alpha = 0
                        }
                       })
        UIView.animate(withDuration: 0.6,
                       delay: 0.3,
                       options: [],
                       animations: {
                        if self.currentPhotoNumber % 2 == 0 {
                            self.nextPhoto.transform = .identity
                        } else {
                            self.currentPhoto.transform = .identity
                        }
                            
                       })
    }
    
    @IBAction func buttonLikes(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        Animations.animationTapToLike(sender)
    }
}
