//
//  MyGroupsTableViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

class MyGroupsTableViewCell: UITableViewCell {

    @IBOutlet weak var myGroups: UILabel!
    
    @IBOutlet weak var myPhotoGroups: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
