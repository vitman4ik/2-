//
//  model.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 10.02.2021.
//

import UIKit

struct FriendModel {
    var name: String
    var coverPhoto: UIImage?
    var photo = [PhotoLibraryModel]()
    
    static func generateFriendsData() -> [FriendModel] {
        
        return [ FriendModel(name: "Nik",
                             coverPhoto: UIImage(named: "Candy Cane"),
                             photo: [ PhotoLibraryModel(image: UIImage(named: "chocolate_coin")!, favouritesCount: 4),
                                      PhotoLibraryModel(image: UIImage(named: "Candy Cane" )!, favouritesCount: 3),
                                      PhotoLibraryModel(image: UIImage(named: "chocolate_coin")!, favouritesCount: 4),
                                      PhotoLibraryModel(image: UIImage(named: "Candy Cane" )!, favouritesCount: 3)]),
                 FriendModel(name: "Nency",
                                      coverPhoto: UIImage(named: "Candy Cane"),
                                      photo: [ PhotoLibraryModel(image: UIImage(named: "chocolate_coin")!, favouritesCount: 10),
                                               PhotoLibraryModel(image: UIImage(named: "Candy Cane" )!, favouritesCount: 50),
                                               PhotoLibraryModel(image: UIImage(named: "chocolate_coin")!, favouritesCount: 4),
                                               PhotoLibraryModel(image: UIImage(named: "Candy Cane" )!, favouritesCount: 3)]),
                 FriendModel(name: "Joe",
                             coverPhoto: UIImage(named: "candy_floss"),
                             photo: [ PhotoLibraryModel(image:UIImage (named: "chocolate_egg")!, favouritesCount: 4),
                                      PhotoLibraryModel(image: UIImage (named: "candy_floss")!, favouritesCount: 10),
                                      PhotoLibraryModel(image: UIImage(named: "chocolate_coin")!, favouritesCount: 4),
                                      PhotoLibraryModel(image: UIImage(named: "Candy Cane" )!, favouritesCount: 3)
        ])]
    }
    
    struct PhotoLibraryModel {
        var image: UIImage
        var favouritesCount: Int
        var isFavourite: Bool = false
    }
}

struct GroupModel {
    var group:String
    var photo: UIImage?
    
    static func 	generateGroupsData() -> [GroupModel] {
        return [ GroupModel(group: "Car", photo: UIImage(named:"Caramel")),
                 GroupModel(group: "Motocycle", photo: UIImage(named: "Chocolate Bar")),
                 GroupModel(group: "Enemy", photo: UIImage(named: "Chocolate Chip"))]
    }
}

struct Users {
    var login:String
    var password:String
}

class AllUsers {
    
    static var user = AllUsers()
    var usersArray = [Users]()
     init(){}
}


struct NewsModel {
    var user: String
    var date: String
    var news: String
    var newsPhoto: [UIImage]
    var userPhoto: UIImage?
    
    static func generateNews() -> [NewsModel] {
        return [ NewsModel(user: "Billi",
                           date: "16.06.2020",
                           news: "Italy's ambassador to the Democratic Republic of Congo has been killed in an attack in the east of the country, its foreign ministry has said.",
                           newsPhoto: [UIImage(named: "kill") ?? UIImage(),
                                       UIImage(named: "boy") ?? UIImage()],
                           userPhoto:  UIImage(named: "Candy Cane")),
                 NewsModel(user: "Milli",
                                   date: "22.02.2020",
                                   news: "The family of an 11-year-old boy who died in recent cold weather in Texas have filed a $100m (£71m) lawsuit against power companies for negligence.",
                                   newsPhoto: [UIImage(named: "boy") ?? UIImage(),
                                               UIImage(named: "kill") ?? UIImage()],
                                   userPhoto: UIImage(named: "candy_floss")
                         )
        ]
    }
    
}


