//
//  HederCollectionReusableView.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 15.02.2021.
//

import UIKit

class HederCollectionReusableView: UICollectionReusableView {
    
    static let identifire = "HederCollectionReusableView"
    
    private let imageV: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        image.backgroundColor = .red
        image.layer.cornerRadius = 50
        image.layer.shadowColor = UIColor.black.cgColor
        image.layer.shadowOpacity = 1
        image.layer.shadowOffset = CGSize.zero
        image.layer.shadowRadius = 10
        
        image.clipsToBounds = false
        return image
    }()
    
    
    private let label: UILabel = {
        let label = UILabel()
        label.text = "1111"
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()
    
    public func configure() {
        backgroundColor = .white
        
        addSubview(label)
        addSubview(imageV)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        label.frame = CGRect(x: 10, y: 10, width: frame.width - 20, height: 20)
        imageV.center = center
    }
    
    func setData(title: String, and image: UIImage) {
        label.text = title
        imageV.image = image
    }
}
