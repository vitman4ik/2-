//
//  FriendsPhotoCollectionViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

class MyDataSource: NSObject, UICollectionViewDataSource {
    
   
    
    var fotoName = [String]()
    var fotoName1 = [UIImage]()
    
    func setupData(fotoName: [String], fotoName1: [UIImage]) {
        self.fotoName = fotoName
        self.fotoName1 = fotoName1
    }
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fotoName.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FotoFriends", for: indexPath) as! FriendsPhotoCollectionViewCell
    
        // Configure the cell
        
        cell.nameFriends.text = fotoName[indexPath.row]
        cell.photoView.image = fotoName1[indexPath.row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
       let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HederCollectionReusableView.identifire, for: indexPath) as! HederCollectionReusableView
       header.configure()
        header.frame = CGRect(x: 0, y: 0, width: collectionView.frame.width, height: 200)
        header.setData(title: fotoName[0], and: fotoName1[0])
       return header
   }
   
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
       return CGSize(width: 100, height: 100)
   }
}


class FriendsPhotoCollectionViewController: UICollectionViewController {
    
    var friend: FriendModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView?.register(HederCollectionReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HederCollectionReusableView.identifire)
    }

    // MARK: UICollectionViewDataSource
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return friend?.photo.count ?? 0
   }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FotoFriends", for: indexPath) as! FriendsPhotoCollectionViewCell
   
       // Configure the cell
       
//       cell.nameFriends.text = "Photo"
        cell.photoView.image = friend?.photo[indexPath.row].image
        if let count = friend?.photo[indexPath.row].favouritesCount {
            cell.countOfFavouritesLabel.text = "\(count)"
        }
        
        cell.favouriteButton.isSelected = friend?.photo[indexPath.row].isFavourite ?? false
        cell.delegate = self
       return cell
   }
   
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
      let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HederCollectionReusableView.identifire, for: indexPath) as! HederCollectionReusableView
      header.configure()
       header.frame = CGRect(x: 0, y: 0, width: collectionView.frame.width, height: 200)
        header.setData(title: friend?.name ?? "", and: friend?.coverPhoto ?? UIImage())
      return header
  }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showAllItems",
           let destination = segue.destination as? PhotoFullSizeViewController {
            destination.profilePhoto = friend?.photo.compactMap({ $0.image }) ?? [UIImage]()	
        }
    }
  
//  func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
//      return CGSize(width: 100, height: 100)
//  }
   

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */
//
//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HederCollectionReusableView.identifire, for: indexPath) as! HederCollectionReusableView
//        header.configure()
//        return header
//    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: view.frame.width, height: 200)
    }
    
}

extension FriendsPhotoCollectionViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.width / 2 - 10, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
}

extension FriendsPhotoCollectionViewController: FriendsPhotoCollectionViewCellDelegate {
    func didPressImage() {
        performSegue(withIdentifier: "showAllItems", sender: nil)
    }
    
    func didPressFavourite(_ isFavurite: Bool) {
        //
    }
}
