//
//  FriendsPhotoCollectionViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 09.02.2021.
//

import UIKit

protocol FriendsPhotoCollectionViewCellDelegate: AnyObject {
    func didPressFavourite(_ isFavurite: Bool)
    func didPressImage()
}

class FriendsPhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoView: UIImageView! {
        didSet {
            setup()
        }
    }
    @IBOutlet weak var nameFriends: UILabel!
    @IBOutlet weak var favouriteButton: UIButton!
    @IBOutlet weak var countOfFavouritesLabel: UILabel!
    
    weak var delegate: FriendsPhotoCollectionViewCellDelegate?
    
    
    func setup() {
        let panGesture = UITapGestureRecognizer(target: self, action: #selector(didPressImageView))
        photoView.addGestureRecognizer(panGesture)
    }
    
    @objc func didPressImageView() {
        delegate?.didPressImage()
    }
    
    @IBAction func didPressFavouriteButton(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        let count = Int(countOfFavouritesLabel.text ?? "0") ?? 0
        let sum = sender.isSelected ? count + 1 : count - 1
        countOfFavouritesLabel.text = "\(sum)"
        delegate?.didPressFavourite(sender.isSelected)
        Animations.animationTapToLike(sender)
    }
 
 
    
    
    
}
