//
//  Animation.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 06.03.2021.
//

import Foundation
import UIKit


class Animations {
    
    public func loadingElement(_ element: UIView, duration: TimeInterval, delay: TimeInterval) {
        UIView.animate(withDuration: duration,
                       delay: delay, options: [.curveLinear, .repeat, .autoreverse],
                       animations: {element.alpha = 0},
                       completion: nil)
        
    }
    
    public func springAnimation(_ view: UIView) {
        let animation = CASpringAnimation(keyPath: "transform.scale")
        animation.fromValue = 0.8
        animation.toValue = 1
        animation.duration = 1
        animation.autoreverses = true
        animation.fillMode = CAMediaTimingFillMode.backwards
        view.layer.add(animation, forKey: nil)
    }
    
static func animationTapToLike(_ element: UIButton) {
    let animation = CASpringAnimation(keyPath: "transform.scale")
    animation.fromValue = 0
    animation.toValue = 1
    animation.duration = 1
    animation.autoreverses = true
    animation.fillMode = CAMediaTimingFillMode.backwards
    element.layer.add(animation, forKey: nil)
}
    
}



