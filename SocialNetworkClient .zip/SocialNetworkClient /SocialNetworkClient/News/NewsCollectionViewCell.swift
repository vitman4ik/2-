//
//  NewsCollectionViewCell.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 22.02.2021.
//

import UIKit

protocol NewsCollectionViewCellDelegate: AnyObject {
    func didPresslike(_ isLike: Bool)
}

class NewsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var userPhoto: UIImageView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var newsUser: UILabel!
    @IBOutlet weak var photoNewsUsers: UIImageView!
    @IBOutlet weak var numberOfLike: UILabel!
    @IBOutlet weak var numberOfLikes: UIButton!
    
    weak var delegate: NewsCollectionViewCellDelegate?
    
    @IBAction func didPressLikes(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        let count: Int = 0
        let sum = sender.isSelected ? count + 1 : count 
        numberOfLike.text = "\(sum)"
        delegate?.didPresslike(sender.isSelected)
        
    }
    
    
    
    
    
    
    
    
}
