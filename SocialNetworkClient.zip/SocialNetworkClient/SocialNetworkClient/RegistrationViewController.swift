//
//  RegistrationViewController.swift
//  SocialNetworkClient
//
//  Created by Віктор Журавльов on 03.02.2021.
//

import UIKit

class RegistrationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goToLogin(_ sender: UIButton) {
        
        performSegue(withIdentifier: "goToLogin", sender: nil)
    }
    
    
}
