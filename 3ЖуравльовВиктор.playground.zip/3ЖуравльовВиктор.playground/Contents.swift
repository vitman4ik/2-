import UIKit
enum Car {
    
    enum Engin {
        case off
        case on
    }
    enum Widows {
        case up
        case down
    }
}


struct SportCar {
    var manufacturer: String
    var yearMade: Int
    var engin = Car.Engin.off
    var windows = Car.Widows.up
    var maxTrank: Int
    var trank = 0
    
    init(manufacturer: String, yearMade: Int, maxTrank: Int ) {
        self.manufacturer = manufacturer
        self.yearMade = yearMade
        self.maxTrank = maxTrank
    }
    
    mutating func lodingTrank( cargo: Int){
        if (cargo >= maxTrank) && ((cargo + trank) >= maxTrank) {
            print("Max Trang less Cargo")
        }else{
            trank = trank + cargo
            print("Cargo is loding, empty space is \(maxTrank - trank)")
        }
    }
    
    mutating func enginOnOrOff( enginOn: Bool) {
        if enginOn == true {
            self.engin = Car.Engin.on
            print("Car engin is \(engin)")
        } else {
            self.engin = Car.Engin.off
            print("Car engin is \(engin)")
        }
    }
    mutating func windowsUpOrDown( windowsUp: Bool) {
        if windowsUp == true {
            self.windows = Car.Widows.up
            print("Car windows is \(windows)")
        } else {
            self.windows = Car.Widows.down
            print("Car windows is \(windows)")
        }
    }
    
}

struct TrunkCar {
    var manufacturer: String
    var yearMade: Int
    var engin = Car.Engin.off
    var windows = Car.Widows.up
    var maxTrank: Int
    var trank = 0
    
    init(manufacturer: String, yearMade: Int, maxTrank: Int ) {
        self.manufacturer = manufacturer
        self.yearMade = yearMade
        self.maxTrank = maxTrank
    }
    
    mutating func lodingTrank( cargo: Int){
        if (cargo >= maxTrank) && ((cargo + trank) >= maxTrank) {
            print("Max Trang less Cargo")
        }else{
            trank = trank + cargo
            print("Cargo is loding, empty space is \(maxTrank - trank)")
        }
    }
    
    mutating func enginOnOrOff( enginOn: Bool) {
        if enginOn == true {
            self.engin = Car.Engin.on
            print("Car engin is \(engin)")
        } else {
            self.engin = Car.Engin.off
            print("Car engin is \(engin)")
        }
    }
    mutating func windowsUpOrDown( windowsUp: Bool) {
        if windowsUp == true {
            self.windows = Car.Widows.up
            print("Car windows is \(windows)")
        } else {
            self.windows = Car.Widows.down
            print("Car windows is \(windows)")
        }
    }
}


var car = SportCar(manufacturer: "Reno", yearMade: 2000, maxTrank: 60)
car.enginOnOrOff(enginOn: true)
car.windowsUpOrDown(windowsUp: true)
car.lodingTrank(cargo: 10)

var trunk = TrunkCar(manufacturer: "Volvo", yearMade: 2015, maxTrank: 2000)
trunk.enginOnOrOff(enginOn: false)
trunk.windowsUpOrDown(windowsUp: false)
trunk.lodingTrank(cargo: 2100)
