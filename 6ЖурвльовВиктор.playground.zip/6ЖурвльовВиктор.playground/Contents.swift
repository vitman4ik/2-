import UIKit


struct Queue<QueueForWhat: Equatable> {
    var totalQueue = [QueueForWhat]()
    
    mutating func push (_ item: QueueForWhat) {
        return totalQueue.append(item)
        
    }
    
    mutating func pop () -> QueueForWhat {
        return totalQueue.removeFirst()
        
    }
    
    func printQueue() {
        for (index, value) in totalQueue.enumerated() {
            print("Item \(index + 1): \(value)")
        }
    }
    
    subscript( index: Int) -> QueueForWhat? {
        
        get{
            if index <= (totalQueue.count - 1) {
                return totalQueue[index]
                
            }else {
                return nil
            }
        }
    }
    
    func filter( value: QueueForWhat) {
        print("Finded \(totalQueue.filter{$0 == value})")
            
    }
}

var lineOfSurnames = Queue<String>()
lineOfSurnames.push("Zhuravlov")
lineOfSurnames.push("Ivanov")
lineOfSurnames.push("Petrov")
lineOfSurnames.printQueue()
lineOfSurnames[7]
lineOfSurnames.filter(value: "Zhuravlov")
