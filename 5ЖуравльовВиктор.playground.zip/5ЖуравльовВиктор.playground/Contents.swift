import UIKit

protocol Car {
    
    var numberOfWheels: Int { get set}
    var numberOfDoors: Int { get set}
    
    func openWindows()
    
    
}

extension Car {
    func openDoor(_ open: Bool) -> Bool {
        if open == true {
            print("Door open")
        } else {
            print("Door closed")
        }
        return open
        
    }
    func startEngine(_ workEngine: Bool) -> Bool {
        return workEngine
    }
}

class TrunkCar: Car, CustomStringConvertible {

    enum TankConnection: CustomStringConvertible {
        case present(volume: Int)
        case notPresent(volume: Int)
        
        var description: String{
            switch self {
            case .present:
                return "Tank is present"
            case .notPresent:
                return "Tank not present"
            }
        }
    }
    enum StatusWindows: CustomStringConvertible {
        case open, closed
        
        var description: String {
            switch self {
            case .open:
                return "Windows is opened"
            case .closed:
                return "Windows is closed"
            }
        }
    }
    var windows: StatusWindows
    var statusTank: TankConnection
    var numberOfWheels: Int
    var numberOfDoors: Int
    var description: String { "\(windows). \(statusTank)" }
      
    init(statusTank: TankConnection, numberOfWheels: Int, numberOfDoors: Int, windows: StatusWindows) {
        self.statusTank = statusTank
        self.numberOfWheels = numberOfWheels
        self.numberOfDoors = numberOfDoors
        self.windows = windows
        
        switch  statusTank {
        case .present(let volume):
            print(volume)
        case .notPresent(let volume):
            print(volume)
        
        }
    }
    
    func changeTank(action: TankConnection) {
        switch action {
        case .present(let volume):
            statusTank = .present(volume: volume)
            print("Max volume is \(volume)")
        case .notPresent(let volume) :
            statusTank = .present(volume: volume)
            print("Max volume is \(volume)")
        }
    }
    
    func openWindows() {
        windows = .open
    }
}


class SportСar: Car, CustomStringConvertible  {
    enum Roof: CustomStringConvertible {
        case isOpened, isClosed, notRemoved
        
        var description: String {
            switch self {
            case .isOpened:
                return "is opened"
            case .isClosed:
                return "is closed"
            case .notRemoved:
                return "not moved"
            }
        }
    }
    
    enum DrivingMode: CustomStringConvertible {
        case normal, inTrack, sport
        
        var description: String {
            switch self {
            case .normal:
                return "max speed is 140 km/h"
            case .inTrack:
                return "max speed is 180 km/h"
            case .sport:
                return "max speed is 240 km/h"
            }
        }
    }
    
    enum StatusWindows: CustomStringConvertible {
        case open, closed
        
        var description: String {
            switch self {
            case .open:
                return "windows is opened"
            case .closed:
                return "windows is closed"
            }
        }
    }
    
    enum Action {
        case roofchChange(Roof)
        case drivingMode(DrivingMode)
        case windows(StatusWindows)
    }
    
    var numberOfWheels: Int
    var numberOfDoors: Int
    var description: String {"The roof \(roof) and \(drivMode) and \(windows)"}
    var roof: Roof
    var drivMode: DrivingMode
    var windows: StatusWindows
    
    init(numberOfWheels: Int, numberOfDoors: Int,roof: Roof, drivMode: DrivingMode, windows: StatusWindows ) {
        self.numberOfWheels = numberOfWheels
        self.numberOfDoors = numberOfDoors
        self.roof = roof
        self.drivMode = drivMode
        self.windows = windows
    }
    
    
    func control(action: Action) {
        switch action {
        case .roofchChange(let status):
            roof = status
        case .drivingMode(let status):
            drivMode = status
        case.windows(let status):
            windows = status
        }
    }
    
    func openWindows() {
        windows = .open
   }
    
}

var volov = TrunkCar(statusTank: .present(volume: 600), numberOfWheels: 6, numberOfDoors: 2, windows: .closed)
volov.changeTank(action: .present(volume: 600))
volov.openDoor(true)
volov.windows = .closed
volov.startEngine(true)
print(volov.description)




var lotus = SportСar(numberOfWheels: 4, numberOfDoors: 2, roof: .isOpened, drivMode: .sport, windows: .closed)
print(lotus.description)
lotus.control(action: .drivingMode(.inTrack))
lotus.control(action: .roofchChange(.isClosed))
lotus.control(action: .windows(.open))
print(lotus.description)
