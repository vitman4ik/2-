import UIKit

// Task 1

func toFindX(variableA:Double, variableB:Double, variableC:Double) ->[Double] {
    
    let diskriminant = (variableB * variableB) - 4 * variableA * variableC
    var rootOfTheEquation = [Double]()
    
    if variableA == 0 {
        
        rootOfTheEquation.append(((-variableB) / variableC))
        return rootOfTheEquation
        
    } else if diskriminant == 0 {
        
        rootOfTheEquation.append(-variableB / (2 * variableA))
        return rootOfTheEquation
        
    } else if diskriminant > 0 {
        
        rootOfTheEquation.append((-variableB + sqrt(diskriminant)) / 2 * variableA)
        rootOfTheEquation.append((-variableB - sqrt(diskriminant)) / 2 * variableA)
        return rootOfTheEquation
        
    } else {
        return rootOfTheEquation
    }
}

// Task 2

let legAC = 8.00
let legCB = 6.00
let legAB = sqrt(legAC * legAC + legCB * legCB)

let perimeter = legAC + legCB + legAB
let squareABC = 0.5 * (legAC * legCB)


// Task 3

func finalSum(interestRate: Double, firstSum: Double, yearDep: Int) -> Double {
    
    var finalSum = firstSum
    
    for _ in 0..<yearDep {
        finalSum = finalSum + (finalSum * interestRate / 100)
    }
    return finalSum
}
