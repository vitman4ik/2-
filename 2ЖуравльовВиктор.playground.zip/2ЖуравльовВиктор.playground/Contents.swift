import UIKit

// Task 1

func evenNumberOrNot( number: Int) -> Bool {
    return number % 2 == 0
}

// Task2

func divisionByThree( number: Int) -> Bool {
    return number % 3 == 0
}

// Task 3.0

var someArry = [Int]()
let numberOfElements = 100

for i in 0...numberOfElements {
    someArry.append(i)
    
}

// Task 4

var newArrey = [Int]()

for i in 0..<someArry.count {
    if (!evenNumberOrNot(number: someArry[i])) && (!divisionByThree(number: someArry[i])) {
        newArrey.append(someArry[i])
    }
}

someArry = newArrey

// Task 5

func fib( numb:Int) ->[Int] {
    
    var fibArrey = [0]
    var a = 0
    var b = 1
    var result = b
    
    for _ in 1..<numb {
        fibArrey.append(result)
        result = a + b
        a = b
        b = result
    }
    return fibArrey
}
var somFibArrey = fib(numb: 50)

// Task 6

var simpleArr : [Int] = []

for i in 2...100 {
    simpleArr.append(i)
}


