import UIKit

struct CarDescription {
    var year: Int
    var price: Int
    let model: Model
}

struct Model {
    let name: String
}

enum ErrorBuyCar: Error {
    case noModel
    case wrongYear
    case notEnoughMoney
}

class BuyingCar {
    
    var catalog = ["EcoSport": CarDescription(year: 2008, price: 4000, model: Model(name: "EcoSport")),
                   "X5": CarDescription(year: 2015, price: 10000, model: Model(name: "X5"))]
    var money: Int
    
    init(money: Int) {
        self.money = money
    }
    
    func tryBuyCar(carToBuy: String, yearToBuy: Int) throws -> Model {
        guard let car = catalog[carToBuy] else {
            throw ErrorBuyCar.noModel
        }
        
        guard  car.year == yearToBuy else {
            throw ErrorBuyCar.wrongYear
        }
        
        guard car.price <= money else {
            throw ErrorBuyCar.notEnoughMoney
        }
        
        money -= car.price
        catalog[carToBuy] = nil
        print("You buy a car")
        return car.model
    }
}

let vasy = BuyingCar(money: 20000)

do {
    _ = try vasy.tryBuyCar(carToBuy: "X5", yearToBuy: 2015)
    _ = try vasy.tryBuyCar(carToBuy: "Tank", yearToBuy: 2000)
} catch ErrorBuyCar.noModel {
    print("No model")
} catch ErrorBuyCar.wrongYear {
    print("No such year")
} catch ErrorBuyCar.notEnoughMoney {
    print("Not Enough Money")
}



